<?php

session_start();
require_once '../includes/config.php';
require_once '../includes/db_connect.php';
require_once '../includes/auth_functions.php';

// Require admin authentication
$auth->requireAdmin();

$db = Database::getInstance();

// Schema compatibility: some databases may not have users.is_active
$hasIsActiveColumn = false;
$isActiveColumnStmt = $db->prepare("SHOW COLUMNS FROM users LIKE 'is_active'");
$isActiveColumnStmt->execute();
$isActiveColumnResult = $isActiveColumnStmt->get_result();
$hasIsActiveColumn = ($isActiveColumnResult && $isActiveColumnResult->num_rows > 0);
$isActiveColumnStmt->close();

function admin_profile_image_url($path) {
    if (empty($path)) {
        return '';
    }
    if (preg_match('/^(https?:)?\/\//i', $path) || strpos($path, 'data:') === 0) {
        return $path;
    }
    if (strpos($path, '../') === 0 || strpos($path, '/') === 0) {
        return $path;
    }
    return '../' . ltrim($path, './');
}

// Handle actions
$action = $_GET['action'] ?? '';
$user_id = $_GET['id'] ?? 0;

// Handle API requests for user data
if (isset($_GET['action']) && $_GET['action'] == 'get_user' && isset($_GET['id'])) {
    $user_id = intval($_GET['id']);
    $sql = $hasIsActiveColumn
        ? "SELECT * FROM users WHERE id = ?"
        : "SELECT users.*, 1 AS is_active FROM users WHERE id = ?";
    $stmt = $db->prepare($sql);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        header('Content-Type: application/json');
        echo json_encode($user);
        exit();
    } else {
        http_response_code(404);
        echo json_encode(['error' => 'User not found']);
        exit();
    }
}

// Handle API request for user statistics
if (isset($_GET['action']) && $_GET['action'] == 'get_user_stats' && isset($_GET['id'])) {
    $user_id = intval($_GET['id']);
    
    $stats = [
        'total_orders' => 0,
        'total_spent' => 0,
        'avg_order_value' => 0,
        'last_order_date' => null,
        'order_statuses' => []
    ];
    
    // Get order statistics
    $order_sql = "SELECT 
                    COUNT(*) as total_orders,
                    SUM(final_amount) as total_spent,
                    AVG(final_amount) as avg_order_value,
                    MAX(created_at) as last_order_date
                  FROM orders 
                  WHERE user_id = ?";
    $order_stmt = $db->prepare($order_sql);
    $order_stmt->bind_param("i", $user_id);
    $order_stmt->execute();
    $order_result = $order_stmt->get_result();
    
    if ($row = $order_result->fetch_assoc()) {
        $stats['total_orders'] = $row['total_orders'] ?? 0;
        $stats['total_spent'] = $row['total_spent'] ?? 0;
        $stats['avg_order_value'] = $row['avg_order_value'] ?? 0;
        $stats['last_order_date'] = $row['last_order_date'] ?? null;
    }
    
    // Get order status distribution
    $status_sql = "SELECT 
                    status, 
                    COUNT(*) as count 
                   FROM orders 
                   WHERE user_id = ? 
                   GROUP BY status";
    $status_stmt = $db->prepare($status_sql);
    $status_stmt->bind_param("i", $user_id);
    $status_stmt->execute();
    $status_result = $status_stmt->get_result();
    
    while ($row = $status_result->fetch_assoc()) {
        $stats['order_statuses'][$row['status']] = $row['count'];
    }
    
    header('Content-Type: application/json');
    echo json_encode($stats);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    switch ($action) {
        case 'add_user':
            // Handle add user
            $username = trim($_POST['username'] ?? '');
            $email = trim($_POST['email'] ?? '');
            $password = $_POST['password'] ?? '';
            $confirm_password = $_POST['confirm_password'] ?? '';
            $full_name = trim($_POST['full_name'] ?? '');
            $role = $_POST['role'] ?? 'user';
            $phone = trim($_POST['phone'] ?? '');
            $address = trim($_POST['address'] ?? '');
            $is_active = isset($_POST['is_active']) ? 1 : 0;
            
            // Validate inputs
            $errors = [];
            
            if (empty($username)) {
                $errors[] = 'Username is required';
            } elseif (strlen($username) < 3) {
                $errors[] = 'Username must be at least 3 characters';
            }
            
            if (empty($email)) {
                $errors[] = 'Email is required';
            } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $errors[] = 'Invalid email format';
            }
            
            if (empty($password)) {
                $errors[] = 'Password is required';
            } elseif (strlen($password) < 6) {
                $errors[] = 'Password must be at least 6 characters';
            } elseif ($password !== $confirm_password) {
                $errors[] = 'Password confirmation does not match';
            }
            
            if (empty($full_name)) {
                $errors[] = 'Full name is required';
            }
            
            // Check if username or email already exists
            $check_sql = "SELECT id FROM users WHERE username = ? OR email = ?";
            $check_stmt = $db->prepare($check_sql);
            $check_stmt->bind_param("ss", $username, $email);
            $check_stmt->execute();
            $check_result = $check_stmt->get_result();
            
            if ($check_result->num_rows > 0) {
                $errors[] = 'Username or email already exists';
            }
            
            if (empty($errors)) {
                $hashed_password = password_hash($password, PASSWORD_BCRYPT);

                if ($hasIsActiveColumn) {
                    $sql = "INSERT INTO users (username, email, password, full_name, role, phone, address, is_active) 
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
                    $stmt = $db->prepare($sql);
                    $stmt->bind_param("sssssssi", $username, $email, $hashed_password, $full_name, $role, $phone, $address, $is_active);
                } else {
                    $sql = "INSERT INTO users (username, email, password, full_name, role, phone, address) 
                            VALUES (?, ?, ?, ?, ?, ?, ?)";
                    $stmt = $db->prepare($sql);
                    $stmt->bind_param("sssssss", $username, $email, $hashed_password, $full_name, $role, $phone, $address);
                }
                
                if ($stmt->execute()) {
                    $_SESSION['success_message'] = 'User added successfully';
                    header('Location: manage_users.php');
                    exit();
                } else {
                    $_SESSION['error_message'] = 'Failed to add user: ' . $stmt->error;
                }
            } else {
                $_SESSION['error_message'] = implode('<br>', $errors);
            }
            break;
            
        case 'update_user':
            $user_id = $_POST['user_id'] ?? 0;
            $full_name = trim($_POST['full_name'] ?? '');
            $email = trim($_POST['email'] ?? '');
            $role = $_POST['role'] ?? 'user';
            $phone = trim($_POST['phone'] ?? '');
            $address = trim($_POST['address'] ?? '');
            $is_active = isset($_POST['is_active']) ? 1 : 0;
            $confirm_password = $_POST['confirm_password'] ?? '';
            
            // Validate inputs
            $errors = [];
            
            if (empty($full_name)) {
                $errors[] = 'Full name is required';
            }
            
            if (empty($email)) {
                $errors[] = 'Email is required';
            } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $errors[] = 'Invalid email format';
            }
            
            // Check if email already exists (excluding current user)
            $check_sql = "SELECT id FROM users WHERE email = ? AND id != ?";
            $check_stmt = $db->prepare($check_sql);
            $check_stmt->bind_param("si", $email, $user_id);
            $check_stmt->execute();
            $check_result = $check_stmt->get_result();
            
            if ($check_result->num_rows > 0) {
                $errors[] = 'Email already exists';
            }
            
            if (empty($errors)) {
                // Handle password update if provided
                if (!empty($_POST['password'])) {
                    $password = $_POST['password'];
                    if (strlen($password) < 6) {
                        $errors[] = 'Password must be at least 6 characters';
                    } elseif ($password !== $confirm_password) {
                        $errors[] = 'Password confirmation does not match';
                    } else {
                        $hashed_password = password_hash($password, PASSWORD_BCRYPT);
                        if ($hasIsActiveColumn) {
                            $sql = "UPDATE users SET 
                                    full_name = ?, email = ?, role = ?, phone = ?, address = ?, 
                                    is_active = ?, password = ?, updated_at = NOW() 
                                    WHERE id = ?";
                            $stmt = $db->prepare($sql);
                            $stmt->bind_param("sssssssi", $full_name, $email, $role, $phone, $address, $is_active, $hashed_password, $user_id);
                        } else {
                            $sql = "UPDATE users SET 
                                    full_name = ?, email = ?, role = ?, phone = ?, address = ?, 
                                    password = ?, updated_at = NOW() 
                                    WHERE id = ?";
                            $stmt = $db->prepare($sql);
                            $stmt->bind_param("ssssssi", $full_name, $email, $role, $phone, $address, $hashed_password, $user_id);
                        }
                    }
                } else {
                    if ($hasIsActiveColumn) {
                        $sql = "UPDATE users SET 
                                full_name = ?, email = ?, role = ?, phone = ?, address = ?, 
                                is_active = ?, updated_at = NOW() 
                                WHERE id = ?";
                        $stmt = $db->prepare($sql);
                        $stmt->bind_param("ssssssi", $full_name, $email, $role, $phone, $address, $is_active, $user_id);
                    } else {
                        $sql = "UPDATE users SET 
                                full_name = ?, email = ?, role = ?, phone = ?, address = ?, 
                                updated_at = NOW() 
                                WHERE id = ?";
                        $stmt = $db->prepare($sql);
                        $stmt->bind_param("sssssi", $full_name, $email, $role, $phone, $address, $user_id);
                    }
                }
                
                if ($stmt->execute()) {
                    $_SESSION['success_message'] = 'User updated successfully';
                    header('Location: manage_users.php');
                    exit();
                } else {
                    $_SESSION['error_message'] = 'Failed to update user: ' . $stmt->error;
                }
            } else {
                $_SESSION['error_message'] = implode('<br>', $errors);
            }
            break;
            
        case 'delete_user':
            $user_id = $_POST['user_id'] ?? 0;
            
            // Don't allow deleting own account
            if ($user_id == $_SESSION['user_id']) {
                $_SESSION['error_message'] = 'You cannot delete your own account';
                header('Location: manage_users.php');
                exit();
            }
            
            // Check if user has orders before deleting
            $check_orders_sql = "SELECT COUNT(*) as order_count FROM orders WHERE user_id = ?";
            $check_orders_stmt = $db->prepare($check_orders_sql);
            $check_orders_stmt->bind_param("i", $user_id);
            $check_orders_stmt->execute();
            $check_result = $check_orders_stmt->get_result();
            $order_count = $check_result->fetch_assoc()['order_count'];
            
            if ($order_count > 0) {
                $_SESSION['error_message'] = 'Cannot delete user with existing orders. Consider deactivating instead.';
                header('Location: manage_users.php');
                exit();
            }
            
            // Delete user from database
            $sql = "DELETE FROM users WHERE id = ?";
            $stmt = $db->prepare($sql);
            $stmt->bind_param("i", $user_id);
            
            if ($stmt->execute()) {
                $_SESSION['success_message'] = 'User deleted successfully';
                header('Location: manage_users.php');
                exit();
            } else {
                $_SESSION['error_message'] = 'Failed to delete user: ' . $stmt->error;
            }
            break;
            
        case 'bulk_action':
            $bulk_action = $_POST['bulk_action'] ?? '';
            $user_ids = $_POST['user_ids'] ?? [];
            
            if (!empty($user_ids) && $bulk_action) {
                $placeholders = str_repeat('?,', count($user_ids) - 1) . '?';
                
                switch ($bulk_action) {
                    case 'delete':
                        // Don't allow deleting own account
                        if (in_array($_SESSION['user_id'], $user_ids)) {
                            $_SESSION['error_message'] = 'You cannot delete your own account';
                            break;
                        }
                        
                        $sql = "DELETE FROM users WHERE id IN ($placeholders)";
                        $stmt = $db->prepare($sql);
                        $stmt->bind_param(str_repeat('i', count($user_ids)), ...$user_ids);
                        $stmt->execute();
                        
                        $_SESSION['success_message'] = 'Selected users deleted successfully';
                        break;
                        
                    case 'activate':
                        if ($hasIsActiveColumn) {
                            $sql = "UPDATE users SET is_active = 1, updated_at = NOW() 
                                    WHERE id IN ($placeholders)";
                            $stmt = $db->prepare($sql);
                            $stmt->bind_param(str_repeat('i', count($user_ids)), ...$user_ids);
                            $stmt->execute();
                            $_SESSION['success_message'] = 'Selected users activated successfully';
                        } else {
                            $_SESSION['error_message'] = 'Status column is not available in this database schema.';
                        }
                        break;
                        
                    case 'deactivate':
                        // Don't allow deactivating own account
                        if (in_array($_SESSION['user_id'], $user_ids)) {
                            $_SESSION['error_message'] = 'You cannot deactivate your own account';
                            break;
                        }
                        
                        if ($hasIsActiveColumn) {
                            $sql = "UPDATE users SET is_active = 0, updated_at = NOW() 
                                    WHERE id IN ($placeholders)";
                            $stmt = $db->prepare($sql);
                            $stmt->bind_param(str_repeat('i', count($user_ids)), ...$user_ids);
                            $stmt->execute();
                            $_SESSION['success_message'] = 'Selected users deactivated successfully';
                        } else {
                            $_SESSION['error_message'] = 'Status column is not available in this database schema.';
                        }
                        break;
                        
                    case 'make_admin':
                        // Don't allow changing own role
                        if (in_array($_SESSION['user_id'], $user_ids)) {
                            $_SESSION['error_message'] = 'You cannot change your own role';
                            break;
                        }
                        
                        $sql = "UPDATE users SET role = 'admin', updated_at = NOW() 
                                WHERE id IN ($placeholders)";
                        $stmt = $db->prepare($sql);
                        $stmt->bind_param(str_repeat('i', count($user_ids)), ...$user_ids);
                        $stmt->execute();
                        
                        $_SESSION['success_message'] = 'Selected users promoted to admin successfully';
                        break;
                        
                    case 'remove_admin':
                        // Don't allow changing own role
                        if (in_array($_SESSION['user_id'], $user_ids)) {
                            $_SESSION['error_message'] = 'You cannot change your own role';
                            break;
                        }
                        
                        $sql = "UPDATE users SET role = 'user', updated_at = NOW() 
                                WHERE id IN ($placeholders)";
                        $stmt = $db->prepare($sql);
                        $stmt->bind_param(str_repeat('i', count($user_ids)), ...$user_ids);
                        $stmt->execute();
                        
                        $_SESSION['success_message'] = 'Selected users demoted to user role successfully';
                        break;
                }
                
                header('Location: manage_users.php');
                exit();
            }
            break;
    }
}

// Get filter parameters
$search = $_GET['search'] ?? '';
$role_filter = $_GET['role'] ?? 'all';
$status_filter = $_GET['status'] ?? 'all';
$page = max(1, intval($_GET['page'] ?? 1));
$limit = 20;
$offset = ($page - 1) * $limit;

// Build query
$where = "WHERE 1=1";
$params = [];
$types = "";

if (!empty($search)) {
    $where .= " AND (username LIKE ? OR email LIKE ? OR full_name LIKE ? OR phone LIKE ?)";
    $search_term = "%{$search}%";
    $params = array_merge($params, [$search_term, $search_term, $search_term, $search_term]);
    $types .= "ssss";
}

if ($role_filter !== 'all') {
    $where .= " AND role = ?";
    $params[] = $role_filter;
    $types .= "s";
}

if ($status_filter !== 'all') {
    if ($hasIsActiveColumn) {
        $where .= " AND is_active = ?";
        $params[] = ($status_filter === 'active' ? 1 : 0);
        $types .= "i";
    }
}

// Get total count
$count_sql = "SELECT COUNT(*) as total FROM users {$where}";
$count_stmt = $db->prepare($count_sql);
if (!empty($params)) {
    $count_stmt->bind_param($types, ...$params);
}
$count_stmt->execute();
$total_rows = $count_stmt->get_result()->fetch_assoc()['total'];
$total_pages = ceil($total_rows / $limit);

// Get users
$sql = $hasIsActiveColumn
    ? "SELECT * FROM users {$where} ORDER BY created_at DESC LIMIT ? OFFSET ?"
    : "SELECT users.*, 1 AS is_active FROM users {$where} ORDER BY created_at DESC LIMIT ? OFFSET ?";
$params[] = $limit;
$params[] = $offset;
$types .= "ii";

$stmt = $db->prepare($sql);
if (!empty($params)) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$users = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Get user stats
$stats = [
    'total' => 0,
    'active' => 0,
    'admins' => 0,
    'today' => 0,
    'active_7_days' => 0
];

$stats_sql = $hasIsActiveColumn
    ? "
    SELECT 
        COUNT(*) as total,
        SUM(CASE WHEN is_active = 1 THEN 1 ELSE 0 END) as active,
        SUM(CASE WHEN role = 'admin' THEN 1 ELSE 0 END) as admins,
        SUM(CASE WHEN DATE(created_at) = CURDATE() THEN 1 ELSE 0 END) as today,
        (
            SELECT COUNT(DISTINCT user_id) 
            FROM orders 
            WHERE DATE(created_at) >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
        ) as active_7_days
    FROM users
"
    : "
    SELECT 
        COUNT(*) as total,
        COUNT(*) as active,
        SUM(CASE WHEN role = 'admin' THEN 1 ELSE 0 END) as admins,
        SUM(CASE WHEN DATE(created_at) = CURDATE() THEN 1 ELSE 0 END) as today,
        (
            SELECT COUNT(DISTINCT user_id) 
            FROM orders 
            WHERE DATE(created_at) >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
        ) as active_7_days
    FROM users
";
$stats_stmt = $db->prepare($stats_sql);
$stats_stmt->execute();
$stats_result = $stats_stmt->get_result();
if ($row = $stats_result->fetch_assoc()) {
    $stats = $row;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Users - Admin Dashboard</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="admin_style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css">
</head>
<body>
    <div class="admin-container">
        <!-- Sidebar -->
        <?php include '../admin/includes/admin_navbar.php'; ?>

        <!-- Main Content -->
        <main class="admin-main">
            <header class="admin-header">
                <h1><i class="fas fa-users"></i> Manage Users</h1>
                <div class="header-actions">
                    <button type="button" class="btn btn-primary" onclick="showUserModal('add')">
                        <i class="fas fa-user-plus"></i> Add New User
                    </button>
                    <button type="button" class="btn btn-secondary" onclick="exportUsers()">
                        <i class="fas fa-download"></i> Export
                    </button>
                </div>
            </header>

            <!-- Success/Error Messages -->
            <?php if (isset($_SESSION['success_message'])): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i> <?php echo $_SESSION['success_message']; ?>
                    <?php unset($_SESSION['success_message']); ?>
                </div>
            <?php endif; ?>
            
            <?php if (isset($_SESSION['error_message'])): ?>
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-circle"></i> <?php echo $_SESSION['error_message']; ?>
                    <?php unset($_SESSION['error_message']); ?>
                </div>
            <?php endif; ?>

            <!-- Stats Cards -->
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-icon" style="background-color: #2196F3;">
                        <i class="fas fa-users"></i>
                    </div>
                    <div class="stat-info">
                        <h3><?php echo $stats['total']; ?></h3>
                        <p>Total Users</p>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon" style="background-color: #4CAF50;">
                        <i class="fas fa-user-check"></i>
                    </div>
                    <div class="stat-info">
                        <h3><?php echo $stats['active']; ?></h3>
                        <p>Active Users</p>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon" style="background-color: #FF9800;">
                        <i class="fas fa-user-shield"></i>
                    </div>
                    <div class="stat-info">
                        <h3><?php echo $stats['admins']; ?></h3>
                        <p>Administrators</p>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon" style="background-color: #9C27B0;">
                        <i class="fas fa-user-plus"></i>
                    </div>
                    <div class="stat-info">
                        <h3><?php echo $stats['today']; ?></h3>
                        <p>New Today</p>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon" style="background-color: #00BCD4;">
                        <i class="fas fa-shopping-cart"></i>
                    </div>
                    <div class="stat-info">
                        <h3><?php echo $stats['active_7_days']; ?></h3>
                        <p>Active (7 days)</p>
                    </div>
                </div>
            </div>

            <!-- Filters -->
            <div class="admin-filters">
                <form method="GET" class="filter-form" id="filterForm">
                    <div class="filter-row">
                        <div class="filter-group">
                            <input type="text" 
                                   name="search" 
                                   placeholder="Search users..." 
                                   value="<?php echo htmlspecialchars($search); ?>">
                            <button type="submit">
                                <i class="fas fa-search"></i>
                            </button>
                        </div>
                        
                        <div class="filter-group">
                            <select name="role" onchange="this.form.submit()">
                                <option value="all" <?php echo $role_filter === 'all' ? 'selected' : ''; ?>>All Roles</option>
                                <option value="user" <?php echo $role_filter === 'user' ? 'selected' : ''; ?>>Users</option>
                                <option value="admin" <?php echo $role_filter === 'admin' ? 'selected' : ''; ?>>Admins</option>
                            </select>
                        </div>
                        
                        <div class="filter-group">
                            <select name="status" onchange="this.form.submit()">
                                <option value="all" <?php echo $status_filter === 'all' ? 'selected' : ''; ?>>All Status</option>
                                <option value="active" <?php echo $status_filter === 'active' ? 'selected' : ''; ?>>Active</option>
                                <option value="inactive" <?php echo $status_filter === 'inactive' ? 'selected' : ''; ?>>Inactive</option>
                            </select>
                        </div>
                        
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-filter"></i> Apply Filters
                        </button>
                        
                        <?php if (!empty($search) || $role_filter !== 'all' || $status_filter !== 'all'): ?>
                            <a href="manage_users.php" class="btn btn-secondary">
                                <i class="fas fa-times"></i> Clear
                            </a>
                        <?php endif; ?>
                    </div>
                </form>
            </div>

            <!-- Bulk Actions -->
            <div class="bulk-actions" id="bulkActions" style="display: none;">
                <form method="POST" id="bulkActionForm">
                    <input type="hidden" name="action" value="bulk_action">
                    <div class="bulk-action-content">
                        <span id="selectedCount">0 users selected</span>
                        <select name="bulk_action" required>
                            <option value="">Select Action</option>
                            <option value="activate">Activate Selected</option>
                            <option value="deactivate">Deactivate Selected</option>
                            <option value="make_admin">Make Admin</option>
                            <option value="remove_admin">Remove Admin</option>
                            <option value="delete">Delete Selected</option>
                        </select>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-play"></i> Apply
                        </button>
                        <button type="button" class="btn btn-secondary" onclick="clearSelection()">
                            <i class="fas fa-times"></i> Clear Selection
                        </button>
                    </div>
                </form>
            </div>

            <!-- Users Table -->
            <div class="admin-card">
                <div class="card-header">
                    <h3>Users (<?php echo $total_rows; ?>)</h3>
                    <div class="card-actions">
                        <button type="button" class="btn-action" onclick="toggleSelectAll()" id="selectAllBtn">
                            <i class="far fa-square"></i> Select All
                        </button>
                        <button type="button" class="btn-action" onclick="refreshTable()">
                            <i class="fas fa-sync-alt"></i> Refresh
                        </button>
                    </div>
                </div>
                <div class="card-body">
                    <?php if (empty($users)): ?>
                        <div class="no-data">
                            <i class="fas fa-users"></i>
                            <p>No users found</p>
                            <button type="button" class="btn btn-primary" onclick="showUserModal('add')">
                                <i class="fas fa-plus"></i> Add Your First User
                            </button>
                        </div>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table class="admin-table" id="usersTable">
                                <thead>
                                    <tr>
                                        <th width="50">
                                            <input type="checkbox" id="masterCheckbox" onchange="toggleSelectAll()">
                                        </th>
                                        <th>User</th>
                                        <th>Contact</th>
                                        <th>Role</th>
                                        <th>Status</th>
                                        <th>Joined</th>
                                        <th>Orders</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($users as $user): ?>
                                        <tr data-user-id="<?php echo $user['id']; ?>">
                                            <td>
                                                <input type="checkbox" class="user-checkbox" 
                                                       value="<?php echo $user['id']; ?>" 
                                                       onchange="updateSelection()">
                                            </td>
                                            <td>
                                                <div class="user-info">
                                                    <div class="user-avatar">
                                                        <?php if (!empty($user['profile_image'])): ?>
                                                            <img src="<?php echo htmlspecialchars(admin_profile_image_url($user['profile_image'])); ?>" 
                                                                 alt="<?php echo htmlspecialchars($user['full_name']); ?>">
                                                        <?php else: ?>
                                                            <div class="avatar-default">
                                                                <i class="fas fa-user"></i>
                                                            </div>
                                                        <?php endif; ?>
                                                    </div>
                                                    <div class="user-details">
                                                        <strong><?php echo htmlspecialchars($user['full_name']); ?></strong>
                                                        <small>@<?php echo htmlspecialchars($user['username']); ?></small>
                                                        <div class="user-meta">
                                                            <span class="user-id">ID: #<?php echo $user['id']; ?></span>
                                                        </div>
                                                    </div>
                                                </div>
                                            </td>
                                            <td>
                                                <div class="contact-info">
                                                    <div class="email">
                                                        <i class="fas fa-envelope"></i>
                                                        <?php echo htmlspecialchars($user['email']); ?>
                                                    </div>
                                                    <?php if (!empty($user['phone'])): ?>
                                                        <div class="phone">
                                                            <i class="fas fa-phone"></i>
                                                            <?php echo htmlspecialchars($user['phone']); ?>
                                                        </div>
                                                    <?php endif; ?>
                                                </div>
                                            </td>
                                            <td>
                                                <span class="role-badge role-<?php echo $user['role']; ?>">
                                                    <?php echo ucfirst($user['role']); ?>
                                                </span>
                                            </td>
                                            <td>
                                                <span class="status-badge status-<?php echo $user['is_active'] ? 'active' : 'inactive'; ?>">
                                                    <?php echo $user['is_active'] ? 'Active' : 'Inactive'; ?>
                                                </span>
                                            </td>
                                            <td>
                                                <div class="date-info">
                                                    <?php echo date('M d, Y', strtotime($user['created_at'])); ?>
                                                    <small><?php echo date('h:i A', strtotime($user['created_at'])); ?></small>
                                                </div>
                                            </td>
                                            <td>
                                                <?php
                                                // Get order count for this user
                                                $order_sql = "SELECT COUNT(*) as order_count FROM orders WHERE user_id = ?";
                                                $order_stmt = $db->prepare($order_sql);
                                                $order_stmt->bind_param("i", $user['id']);
                                                $order_stmt->execute();
                                                $order_count = $order_stmt->get_result()->fetch_assoc()['order_count'];
                                                ?>
                                                <div class="order-count">
                                                    <i class="fas fa-shopping-cart"></i>
                                                    <span><?php echo $order_count; ?></span>
                                                </div>
                                            </td>
                                            <td>
                                                <div class="action-buttons">
                                                    <button type="button" 
                                                            class="btn-action btn-view" 
                                                            onclick="viewUser(<?php echo $user['id']; ?>)" 
                                                            title="View Details">
                                                        <i class="fas fa-eye"></i>
                                                    </button>
                                                    
                                                    <button type="button" 
                                                            class="btn-action btn-edit" 
                                                            onclick="editUser(<?php echo $user['id']; ?>)" 
                                                            title="Edit">
                                                        <i class="fas fa-edit"></i>
                                                    </button>
                                                    
                                                    <?php if ($user['id'] != $_SESSION['user_id']): ?>
                                                    <button type="button" 
                                                            class="btn-action btn-delete" 
                                                            onclick='deleteUser(<?php echo (int) $user["id"]; ?>, <?php echo htmlspecialchars(json_encode($user["full_name"]), ENT_QUOTES, "UTF-8"); ?>)' 
                                                            title="Delete">
                                                        <i class="fas fa-trash"></i>
                                                    </button>
                                                    <?php endif; ?>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>

                        <!-- Pagination -->
                        <?php if ($total_pages > 1): ?>
                            <div class="pagination">
                                <?php if ($page > 1): ?>
                                    <a href="?<?php echo http_build_query(array_merge($_GET, ['page' => $page - 1])); ?>" class="page-link">
                                        <i class="fas fa-chevron-left"></i> Previous
                                    </a>
                                <?php endif; ?>
                                
                                <div class="page-numbers">
                                    <?php
                                    $start = max(1, $page - 2);
                                    $end = min($total_pages, $page + 2);
                                    
                                    for ($i = $start; $i <= $end; $i++):
                                    ?>
                                        <a href="?<?php echo http_build_query(array_merge($_GET, ['page' => $i])); ?>" 
                                           class="page-link <?php echo $i == $page ? 'active' : ''; ?>">
                                            <?php echo $i; ?>
                                        </a>
                                    <?php endfor; ?>
                                </div>
                                
                                <?php if ($page < $total_pages): ?>
                                    <a href="?<?php echo http_build_query(array_merge($_GET, ['page' => $page + 1])); ?>" class="page-link">
                                        Next <i class="fas fa-chevron-right"></i>
                                    </a>
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            </div>
        </main>
    </div>

    <!-- Add/Edit User Modal -->
    <div class="modal" id="userModal">
        <div class="modal-content large-modal">
            <div class="modal-header">
                <h2 id="modalTitle">Add New User</h2>
                <button type="button" onclick="closeUserModal()">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <div class="modal-body">
                <form method="POST" id="userForm">
                    <input type="hidden" id="actionType" name="action" value="add_user">
                    <input type="hidden" id="userId" name="user_id" value="">
                    
                    <div class="form-tabs">
                        <button type="button" class="tab-btn active" data-tab="basic">Basic Info</button>
                        <button type="button" class="tab-btn" data-tab="contact">Contact Info</button>
                        <button type="button" class="tab-btn" data-tab="security">Security</button>
                    </div>
                    
                    <div class="tab-content active" id="basicTab">
                        <div class="form-row">
                            <div class="form-group">
                                <label for="full_name">Full Name *</label>
                                <input type="text" id="full_name" name="full_name" class="form-control" required>
                            </div>
                            
                            <div class="form-group">
                                <label for="username">Username *</label>
                                <input type="text" id="username" name="username" class="form-control" required>
                            </div>
                        </div>
                        
                        <div class="form-row">
                            <div class="form-group">
                                <label for="email">Email Address *</label>
                                <input type="email" id="email" name="email" class="form-control" required>
                            </div>
                            
                            <div class="form-group">
                                <label for="role">Role *</label>
                                <select id="role" name="role" class="form-control" required>
                                    <option value="user">User</option>
                                    <option value="admin">Administrator</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    
                    <div class="tab-content" id="contactTab">
                        <div class="form-group">
                            <label for="phone">Phone Number</label>
                            <input type="tel" id="phone" name="phone" class="form-control">
                        </div>
                        
                        <div class="form-group">
                            <label for="address">Address</label>
                            <textarea id="address" name="address" class="form-control" rows="3"></textarea>
                        </div>
                        
                        <div class="form-group">
                            <label class="checkbox-label">
                                <input type="checkbox" id="is_active" name="is_active" value="1" checked>
                                <span>Active Account</span>
                            </label>
                        </div>
                    </div>
                    
                    <div class="tab-content" id="securityTab">
                        <div class="form-group">
                            <label for="password">Password *</label>
                            <input type="password" id="password" name="password" class="form-control" required>
                            <small class="form-text" id="passwordHelp">Enter a password for the new user</small>
                        </div>
                        
                        <div class="form-group">
                            <label for="confirm_password">Confirm Password *</label>
                            <input type="password" id="confirm_password" name="confirm_password" class="form-control" required>
                        </div>
                        
                        <div class="password-strength">
                            <div class="strength-meter">
                                <div class="strength-bar"></div>
                            </div>
                            <small class="form-text">Password strength: <span id="strengthText">None</span></small>
                        </div>
                    </div>
                    
                    <div class="modal-actions">
                        <button type="button" class="btn btn-secondary" onclick="closeUserModal()">
                            Cancel
                        </button>
                        <button type="submit" class="btn btn-primary" id="submitBtn">
                            <i class="fas fa-save"></i> Save User
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- View User Modal -->
    <div class="modal" id="viewUserModal">
        <div class="modal-content large-modal">
            <div class="modal-header">
                <h2 id="viewModalTitle">User Details</h2>
                <button type="button" onclick="closeViewUserModal()">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <div class="modal-body">
                <div class="user-view">
                    <div class="user-view-header">
                        <div class="user-avatar-large">
                            <div id="viewUserAvatar" class="avatar-large">
                                <i class="fas fa-user"></i>
                            </div>
                        </div>
                        <div class="user-header-info">
                            <h3 id="viewUserName"></h3>
                            <div class="user-meta">
                                <span class="username" id="viewUserUsername"></span>
                                <span class="user-id" id="viewUserId"></span>
                            </div>
                            <div class="user-status">
                                <span class="role-badge" id="viewUserRole"></span>
                                <span class="status-badge" id="viewUserStatus"></span>
                            </div>
                        </div>
                    </div>
                    
                    <div class="user-view-tabs">
                        <button type="button" class="view-tab-btn active" data-tab="profile">Profile</button>
                        <button type="button" class="view-tab-btn" data-tab="orders">Orders</button>
                        <button type="button" class="view-tab-btn" data-tab="activity">Activity</button>
                    </div>
                    
                    <div class="user-view-content">
                        <div class="view-tab-content active" id="profileTab">
                            <div class="info-grid">
                                <div class="info-item">
                                    <label><i class="fas fa-envelope"></i> Email</label>
                                    <p id="viewUserEmail"></p>
                                </div>
                                <div class="info-item">
                                    <label><i class="fas fa-phone"></i> Phone</label>
                                    <p id="viewUserPhone"></p>
                                </div>
                                <div class="info-item">
                                    <label><i class="fas fa-map-marker-alt"></i> Address</label>
                                    <p id="viewUserAddress"></p>
                                </div>
                                <div class="info-item">
                                    <label><i class="fas fa-calendar-alt"></i> Joined</label>
                                    <p id="viewUserJoined"></p>
                                </div>
                                <div class="info-item">
                                    <label><i class="fas fa-clock"></i> Last Updated</label>
                                    <p id="viewUserUpdated"></p>
                                </div>
                            </div>
                        </div>
                        
                        <div class="view-tab-content" id="ordersTab">
                            <div class="stats-grid small">
                                <div class="stat-card">
                                    <div class="stat-icon" style="background-color: #4CAF50;">
                                        <i class="fas fa-shopping-cart"></i>
                                    </div>
                                    <div class="stat-info">
                                        <h3 id="totalOrders">0</h3>
                                        <p>Total Orders</p>
                                    </div>
                                </div>
                                
                                <div class="stat-card">
                                    <div class="stat-icon" style="background-color: #2196F3;">
                                        <i class="fas fa-dollar-sign"></i>
                                    </div>
                                    <div class="stat-info">
                                        <h3 id="totalSpent">$0.00</h3>
                                        <p>Total Spent</p>
                                    </div>
                                </div>
                                
                                <div class="stat-card">
                                    <div class="stat-icon" style="background-color: #FF9800;">
                                        <i class="fas fa-chart-bar"></i>
                                    </div>
                                    <div class="stat-info">
                                        <h3 id="avgOrderValue">$0.00</h3>
                                        <p>Avg Order Value</p>
                                    </div>
                                </div>
                                
                                <div class="stat-card">
                                    <div class="stat-icon" style="background-color: #9C27B0;">
                                        <i class="fas fa-calendar-check"></i>
                                    </div>
                                    <div class="stat-info">
                                        <p id="lastOrderDate">Never</p>
                                        <p>Last Order</p>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="order-status-chart">
                                <canvas id="orderStatusChart"></canvas>
                            </div>
                        </div>
                        
                        <div class="view-tab-content" id="activityTab">
                            <div class="activity-timeline" id="activityTimeline">
                                <!-- Activity will be loaded here -->
                            </div>
                        </div>
                    </div>
                    
                    <div class="user-view-actions">
                        <button type="button" class="btn btn-primary" onclick="editCurrentUser()">
                            <i class="fas fa-edit"></i> Edit User
                        </button>
                        <button type="button" class="btn btn-secondary" onclick="sendMessageToUser()">
                            <i class="fas fa-envelope"></i> Send Message
                        </button>
                        <button type="button" class="btn btn-danger" onclick="deleteCurrentUser()">
                            <i class="fas fa-trash"></i> Delete User
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Delete Confirmation Modal -->
    <div class="modal" id="deleteModal">
        <div class="modal-content">
            <div class="modal-header">
                <h2><i class="fas fa-exclamation-triangle"></i> Confirm Delete</h2>
                <button type="button" onclick="closeDeleteModal()">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <div class="modal-body">
                <div class="warning-message">
                    <i class="fas fa-exclamation-circle"></i>
                    <p>Are you sure you want to delete <strong id="deleteUserName"></strong>?</p>
                    <p class="text-danger">This action cannot be undone!</p>
                    <p><small>Note: Users with existing orders cannot be deleted.</small></p>
                </div>
                
                <form method="POST" id="deleteForm">
                    <input type="hidden" name="action" value="delete_user">
                    <input type="hidden" id="deleteUserId" name="user_id" value="">
                    
                    <div class="modal-actions">
                        <button type="button" class="btn btn-secondary" onclick="closeDeleteModal()">
                            Cancel
                        </button>
                        <button type="submit" class="btn btn-danger">
                            <i class="fas fa-trash"></i> Delete User
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Scripts -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <script>
        function toAdminImageUrl(path) {
            if (!path) return '';
            if (/^(https?:)?\/\//i.test(path) || path.startsWith('data:')) return path;
            if (path.startsWith('../') || path.startsWith('/')) return path;
            return '../' + path.replace(/^\.?\//, '');
        }

        // Initialize DataTable
        $(document).ready(function() {
            $('#usersTable').DataTable({
                paging: false,
                searching: false,
                info: false,
                order: [],
                columnDefs: [
                    { orderable: false, targets: [0, 7] }
                ]
            });
        });

        // Tab switching for user modal
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                const tab = this.dataset.tab;
                
                // Update active tab button
                document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
                this.classList.add('active');
                
                // Show selected tab content
                document.querySelectorAll('.tab-content').forEach(content => {
                    content.classList.remove('active');
                });
                document.getElementById(tab + 'Tab').classList.add('active');
            });
        });

        // Tab switching for view modal
        document.querySelectorAll('.view-tab-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                const tab = this.dataset.tab;
                
                // Update active tab button
                document.querySelectorAll('.view-tab-btn').forEach(b => b.classList.remove('active'));
                this.classList.add('active');
                
                // Show selected tab content
                document.querySelectorAll('.view-tab-content').forEach(content => {
                    content.classList.remove('active');
                });
                document.getElementById(tab + 'Tab').classList.add('active');
            });
        });

        // Show user modal for add/edit
        function showUserModal(action) {
            if (action === 'add') {
                document.getElementById('modalTitle').textContent = 'Add New User';
                document.getElementById('actionType').value = 'add_user';
                document.getElementById('userId').value = '';
                document.getElementById('userForm').reset();
                document.getElementById('username').readOnly = false;
                document.getElementById('password').required = true;
                document.getElementById('confirm_password').required = true;
                document.getElementById('password').value = '';
                document.getElementById('confirm_password').value = '';
                document.getElementById('passwordHelp').textContent = 'Enter a password for the new user';
                document.getElementById('submitBtn').innerHTML = '<i class="fas fa-save"></i> Save User';
            }
            
            document.getElementById('userModal').style.display = 'block';
            document.body.style.overflow = 'hidden';
        }

        // Close user modal
        function closeUserModal() {
            document.getElementById('userModal').style.display = 'none';
            document.body.style.overflow = 'auto';
        }

        // Edit user
        async function editUser(userId) {
            try {
                const response = await fetch(`manage_users.php?action=get_user&id=${userId}`);
                const user = await response.json();
                
                if (user.error) {
                    showNotification(user.error, 'error');
                    return;
                }
                
                document.getElementById('modalTitle').textContent = 'Edit User';
                document.getElementById('actionType').value = 'update_user';
                document.getElementById('userId').value = user.id;
                document.getElementById('full_name').value = user.full_name || '';
                document.getElementById('username').value = user.username || '';
                document.getElementById('username').readOnly = true;
                document.getElementById('email').value = user.email || '';
                document.getElementById('role').value = user.role || 'user';
                document.getElementById('phone').value = user.phone || '';
                document.getElementById('address').value = user.address || '';
                document.getElementById('is_active').checked = user.is_active == 1;
                
                // Password fields
                document.getElementById('password').required = false;
                document.getElementById('confirm_password').required = false;
                document.getElementById('password').value = '';
                document.getElementById('confirm_password').value = '';
                document.getElementById('passwordHelp').textContent = 'Leave empty to keep current password';
                document.getElementById('submitBtn').innerHTML = '<i class="fas fa-save"></i> Update User';
                
                document.getElementById('userModal').style.display = 'block';
                document.body.style.overflow = 'hidden';
            } catch (error) {
                console.error('Error:', error);
                showNotification('Failed to load user data', 'error');
            }
        }

        // View user details
        let currentViewUserId = null;
        let orderStatusChartInstance = null;
        
        async function viewUser(userId) {
            try {
                currentViewUserId = userId;
                
                // Load user data
                const userResponse = await fetch(`manage_users.php?action=get_user&id=${userId}`);
                const user = await userResponse.json();
                
                if (user.error) {
                    showNotification(user.error, 'error');
                    return;
                }
                
                // Load user statistics
                const statsResponse = await fetch(`manage_users.php?action=get_user_stats&id=${userId}`);
                const stats = await statsResponse.json();
                
                // Populate user info
                document.getElementById('viewModalTitle').textContent = 'User Details';
                document.getElementById('viewUserName').textContent = user.full_name || 'Unknown';
                document.getElementById('viewUserUsername').textContent = '@' + (user.username || '');
                document.getElementById('viewUserId').textContent = 'ID: #' + user.id;

                const avatarContainer = document.getElementById('viewUserAvatar');
                if (avatarContainer) {
                    if (user.profile_image) {
                        avatarContainer.innerHTML = `<img src="${toAdminImageUrl(user.profile_image)}" alt="${user.full_name || 'User'}">`;
                    } else {
                        avatarContainer.innerHTML = '<i class="fas fa-user"></i>';
                    }
                }
                
                // Set role badge
                const roleBadge = document.getElementById('viewUserRole');
                roleBadge.textContent = user.role ? user.role.charAt(0).toUpperCase() + user.role.slice(1) : 'User';
                roleBadge.className = 'role-badge role-' + (user.role || 'user');
                
                // Set status badge
                const statusBadge = document.getElementById('viewUserStatus');
                statusBadge.textContent = user.is_active == 1 ? 'Active' : 'Inactive';
                statusBadge.className = 'status-badge status-' + (user.is_active == 1 ? 'active' : 'inactive');
                
                // Populate contact info
                document.getElementById('viewUserEmail').textContent = user.email || 'Not provided';
                document.getElementById('viewUserPhone').textContent = user.phone || 'Not provided';
                document.getElementById('viewUserAddress').textContent = user.address || 'Not provided';
                document.getElementById('viewUserJoined').textContent = user.created_at ? 
                    new Date(user.created_at).toLocaleString() : 'Unknown';
                document.getElementById('viewUserUpdated').textContent = user.updated_at ? 
                    new Date(user.updated_at).toLocaleString() : 'Never';
                
                // Populate statistics
                document.getElementById('totalOrders').textContent = stats.total_orders || 0;
                document.getElementById('totalSpent').textContent = '$' + (stats.total_spent ? 
                    parseFloat(stats.total_spent).toFixed(2) : '0.00');
                document.getElementById('avgOrderValue').textContent = '$' + (stats.avg_order_value ? 
                    parseFloat(stats.avg_order_value).toFixed(2) : '0.00');
                document.getElementById('lastOrderDate').textContent = stats.last_order_date ? 
                    new Date(stats.last_order_date).toLocaleDateString() : 'Never';
                
                // Create order status chart
                createOrderStatusChart(stats.order_statuses);
                
                // Load activity
                loadUserActivity(userId);
                
                document.getElementById('viewUserModal').style.display = 'block';
                document.body.style.overflow = 'hidden';
            } catch (error) {
                console.error('Error:', error);
                showNotification('Failed to load user details', 'error');
            }
        }

        // Create order status chart
        function createOrderStatusChart(orderStatuses) {
            const ctx = document.getElementById('orderStatusChart').getContext('2d');
            if (orderStatusChartInstance) {
                orderStatusChartInstance.destroy();
            }
            
            const labels = Object.keys(orderStatuses);
            const data = Object.values(orderStatuses);
            const colors = {
                'pending': '#FF9800',
                'confirmed': '#2196F3',
                'processing': '#9C27B0',
                'shipped': '#00BCD4',
                'delivered': '#4CAF50',
                'cancelled': '#F44336'
            };
            
            const backgroundColors = labels.map(label => colors[label] || '#607D8B');
            
            orderStatusChartInstance = new Chart(ctx, {
                type: 'doughnut',
                data: {
                    labels: labels.map(label => label.charAt(0).toUpperCase() + label.slice(1)),
                    datasets: [{
                        data: data,
                        backgroundColor: backgroundColors,
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    plugins: {
                        legend: {
                            position: 'bottom'
                        }
                    }
                }
            });
        }

        // Load user activity
        async function loadUserActivity(userId) {
            const timeline = document.getElementById('activityTimeline');
            timeline.innerHTML = '<div class="loading">Loading activity...</div>';
            
            // In a real application, you would fetch activity data from the server
            setTimeout(() => {
                const activities = [
                    { date: 'Today, 10:30 AM', action: 'Placed new order #ORD-2024-00123', icon: 'shopping-cart', color: '#4CAF50' },
                    { date: 'Yesterday, 3:45 PM', action: 'Updated profile information', icon: 'user-edit', color: '#2196F3' },
                    { date: '2 days ago', action: 'Submitted a review for "Spaghetti Carbonara"', icon: 'star', color: '#FF9800' },
                    { date: '1 week ago', action: 'Changed password', icon: 'key', color: '#9C27B0' },
                    { date: '2 weeks ago', action: 'Registered account', icon: 'user-plus', color: '#00BCD4' }
                ];
                
                timeline.innerHTML = activities.map(activity => `
                    <div class="activity-item">
                        <div class="activity-icon" style="background-color: ${activity.color};">
                            <i class="fas fa-${activity.icon}"></i>
                        </div>
                        <div class="activity-content">
                            <p class="activity-action">${activity.action}</p>
                            <small class="activity-date">${activity.date}</small>
                        </div>
                    </div>
                `).join('');
            }, 500);
        }

        // Close view user modal
        function closeViewUserModal() {
            document.getElementById('viewUserModal').style.display = 'none';
            document.body.style.overflow = 'auto';
            if (orderStatusChartInstance) {
                orderStatusChartInstance.destroy();
                orderStatusChartInstance = null;
            }
        }

        // Edit current viewed user
        function editCurrentUser() {
            if (currentViewUserId) {
                closeViewUserModal();
                editUser(currentViewUserId);
            }
        }

        // Delete current viewed user
        function deleteCurrentUser() {
            if (currentViewUserId) {
                closeViewUserModal();
                // Get user name from the view modal
                const userName = document.getElementById('viewUserName').textContent;
                deleteUser(currentViewUserId, userName);
            }
        }

        // Send message to user (placeholder)
        function sendMessageToUser() {
            alert('Message functionality would be implemented here');
        }

        // Delete user confirmation
        function deleteUser(userId, userName) {
            document.getElementById('deleteUserName').textContent = userName;
            document.getElementById('deleteUserId').value = userId;
            document.getElementById('deleteModal').style.display = 'block';
            document.body.style.overflow = 'hidden';
        }

        // Close delete modal
        function closeDeleteModal() {
            document.getElementById('deleteModal').style.display = 'none';
            document.body.style.overflow = 'auto';
        }

        // Bulk selection functions
        let selectedUsers = [];

        function toggleSelectAll() {
            const checkboxes = document.querySelectorAll('.user-checkbox');
            const masterCheckbox = document.getElementById('masterCheckbox');
            const selectAllBtn = document.getElementById('selectAllBtn');
            
            const allChecked = Array.from(checkboxes).every(cb => cb.checked);
            
            checkboxes.forEach(cb => {
                cb.checked = !allChecked;
                cb.dispatchEvent(new Event('change'));
            });
            
            masterCheckbox.checked = !allChecked;
            selectAllBtn.innerHTML = !allChecked ? 
                '<i class="far fa-check-square"></i> Deselect All' : 
                '<i class="far fa-square"></i> Select All';
        }

        function updateSelection() {
            selectedUsers = Array.from(document.querySelectorAll('.user-checkbox:checked'))
                .map(cb => cb.value);
            
            const selectedCount = selectedUsers.length;
            const bulkActions = document.getElementById('bulkActions');
            const selectedCountSpan = document.getElementById('selectedCount');
            
            if (selectedCount > 0) {
                bulkActions.style.display = 'block';
                selectedCountSpan.textContent = `${selectedCount} user${selectedCount > 1 ? 's' : ''} selected`;
            } else {
                bulkActions.style.display = 'none';
            }
        }

        function clearSelection() {
            document.querySelectorAll('.user-checkbox').forEach(cb => {
                cb.checked = false;
            });
            document.getElementById('masterCheckbox').checked = false;
            updateSelection();
        }

        // Password strength checker
        document.getElementById('password').addEventListener('input', function() {
            const password = this.value;
            const strengthBar = document.querySelector('.strength-bar');
            const strengthText = document.getElementById('strengthText');
            
            let strength = 0;
            
            // Check password length
            if (password.length >= 8) strength++;
            
            // Check for lowercase
            if (/[a-z]/.test(password)) strength++;
            
            // Check for uppercase
            if (/[A-Z]/.test(password)) strength++;
            
            // Check for numbers
            if (/[0-9]/.test(password)) strength++;
            
            // Check for special characters
            if (/[^A-Za-z0-9]/.test(password)) strength++;
            
            // Update strength bar
            const width = strength * 20;
            strengthBar.style.width = width + '%';
            
            // Update colors and text
            if (strength === 0) {
                strengthBar.style.backgroundColor = '#e0e0e0';
                strengthText.textContent = 'None';
            } else if (strength <= 2) {
                strengthBar.style.backgroundColor = '#f44336';
                strengthText.textContent = 'Weak';
            } else if (strength <= 3) {
                strengthBar.style.backgroundColor = '#ff9800';
                strengthText.textContent = 'Fair';
            } else if (strength <= 4) {
                strengthBar.style.backgroundColor = '#4caf50';
                strengthText.textContent = 'Good';
            } else {
                strengthBar.style.backgroundColor = '#2196f3';
                strengthText.textContent = 'Strong';
            }
        });

        // Form validation
        document.getElementById('userForm').addEventListener('submit', function(e) {
            const action = document.getElementById('actionType').value;
            const password = document.getElementById('password').value;
            const confirmPassword = document.getElementById('confirm_password').value;
            
            if (action === 'add_user' && (!password || !confirmPassword)) {
                e.preventDefault();
                showNotification('Password and confirmation are required for new users', 'error');
                return false;
            }
            
            if (password && password !== confirmPassword) {
                e.preventDefault();
                showNotification('Passwords do not match', 'error');
                return false;
            }
            
            if (action === 'add_user' && password.length < 6) {
                e.preventDefault();
                showNotification('Password must be at least 6 characters', 'error');
                return false;
            }
            
            return true;
        });

        // Export users
        function exportUsers() {
            const params = new URLSearchParams(window.location.search);
            window.location.href = `export_users.php?${params.toString()}`;
        }

        // Refresh table
        function refreshTable() {
            window.location.reload();
        }

        // Show notification
        function showNotification(message, type = 'info') {
            const notification = document.createElement('div');
            notification.className = `notification notification-${type}`;
            notification.innerHTML = `
                <i class="fas fa-${type === 'success' ? 'check-circle' : type === 'error' ? 'exclamation-circle' : 'info-circle'}"></i>
                ${message}
            `;
            document.body.appendChild(notification);
            
            setTimeout(() => {
                notification.remove();
            }, 3000);
        }

        // Close modals when clicking outside
        window.onclick = function(event) {
            const modals = ['userModal', 'viewUserModal', 'deleteModal'];
            modals.forEach(modalId => {
                const modal = document.getElementById(modalId);
                if (modal && event.target === modal) {
                    if (modalId === 'userModal') closeUserModal();
                    if (modalId === 'viewUserModal') closeViewUserModal();
                    if (modalId === 'deleteModal') closeDeleteModal();
                }
            });
        };
    </script>

    <style>
        /* Additional Styles for User Management */
        .large-modal {
            max-width: 800px;
        }
        
        .user-info {
            display: flex;
            align-items: center;
            gap: 1rem;
        }
        
        .user-avatar {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            overflow: hidden;
            flex-shrink: 0;
        }
        
        .user-avatar img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        
        .avatar-default {
            width: 100%;
            height: 100%;
            background: #f7fafc;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #cbd5e0;
            font-size: 1.25rem;
        }
        
        .user-details {
            flex: 1;
        }
        
        .user-details strong {
            display: block;
            margin-bottom: 0.25rem;
        }
        
        .user-details small {
            color: #718096;
            font-size: 0.85rem;
        }
        
        .user-meta {
            margin-top: 0.25rem;
            font-size: 0.8rem;
            color: #a0aec0;
        }
        
        .contact-info {
            display: flex;
            flex-direction: column;
            gap: 0.25rem;
        }
        
        .contact-info .email,
        .contact-info .phone {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            font-size: 0.9rem;
        }
        
        .contact-info i {
            color: #667eea;
            width: 16px;
        }
        
        .role-badge {
            display: inline-block;
            padding: 0.3rem 0.75rem;
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: 500;
        }
        
        .role-user {
            background: #e2e8f0;
            color: #4a5568;
        }
        
        .role-admin {
            background: #c6f6d5;
            color: #22543d;
        }
        
        .status-badge {
            display: inline-block;
            padding: 0.3rem 0.75rem;
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: 500;
        }
        
        .status-active {
            background: #c6f6d5;
            color: #22543d;
        }
        
        .status-inactive {
            background: #fed7d7;
            color: #742a2a;
        }
        
        .date-info {
            display: flex;
            flex-direction: column;
            gap: 0.25rem;
        }
        
        .date-info small {
            color: #718096;
            font-size: 0.85rem;
        }
        
        .order-count {
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        
        .order-count i {
            color: #667eea;
        }
        
        .action-buttons {
            display: flex;
            gap: 0.5rem;
        }
        
        .btn-action {
            width: 36px;
            height: 36px;
            border-radius: 6px;
            border: none;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.3s;
        }
        
        .btn-view {
            background: #e2e8f0;
            color: #4a5568;
        }
        
        .btn-view:hover {
            background: #cbd5e0;
        }
        
        .btn-edit {
            background: #bee3f8;
            color: #2b6cb0;
        }
        
        .btn-edit:hover {
            background: #90cdf4;
        }
        
        .btn-delete {
            background: #fed7d7;
            color: #c53030;
        }
        
        .btn-delete:hover {
            background: #feb2b2;
        }
        
        .form-tabs {
            display: flex;
            border-bottom: 1px solid #e2e8f0;
            margin-bottom: 1.5rem;
        }
        
        .tab-btn {
            padding: 0.75rem 1.5rem;
            background: none;
            border: none;
            border-bottom: 2px solid transparent;
            color: #4a5568;
            cursor: pointer;
            font-weight: 500;
            transition: all 0.3s;
        }
        
        .tab-btn.active {
            color: #667eea;
            border-bottom-color: #667eea;
        }
        
        .tab-content {
            display: none;
        }
        
        .tab-content.active {
            display: block;
        }
        
        .password-strength {
            margin-top: 1rem;
        }
        
        .strength-meter {
            width: 100%;
            height: 4px;
            background: #e2e8f0;
            border-radius: 2px;
            overflow: hidden;
            margin-bottom: 0.5rem;
        }
        
        .strength-bar {
            height: 100%;
            width: 0%;
            transition: all 0.3s;
        }
        
        /* View User Modal Styles */
        .user-view {
            display: flex;
            flex-direction: column;
            gap: 1.5rem;
        }
        
        .user-view-header {
            display: flex;
            align-items: center;
            gap: 1.5rem;
            padding-bottom: 1.5rem;
            border-bottom: 1px solid #e2e8f0;
        }
        
        .user-avatar-large {
            width: 100px;
            height: 100px;
            border-radius: 50%;
            overflow: hidden;
            flex-shrink: 0;
        }
        
        .avatar-large {
            width: 100%;
            height: 100%;
            background: #667eea;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 2.5rem;
        }

        .avatar-large img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            display: block;
        }
        
        .user-header-info {
            flex: 1;
        }
        
        .user-header-info h3 {
            margin: 0 0 0.5rem 0;
            font-size: 1.5rem;
        }
        
        .user-meta {
            display: flex;
            gap: 1rem;
            margin-bottom: 1rem;
        }
        
        .username {
            background: #e2e8f0;
            padding: 0.25rem 0.75rem;
            border-radius: 20px;
            font-size: 0.9rem;
        }
        
        .user-id {
            color: #718096;
            font-size: 0.9rem;
            display: flex;
            align-items: center;
        }
        
        .user-status {
            display: flex;
            gap: 0.5rem;
        }
        
        .user-view-tabs {
            display: flex;
            border-bottom: 1px solid #e2e8f0;
        }
        
        .view-tab-btn {
            padding: 0.75rem 1.5rem;
            background: none;
            border: none;
            border-bottom: 2px solid transparent;
            color: #4a5568;
            cursor: pointer;
            font-weight: 500;
            transition: all 0.3s;
        }
        
        .view-tab-btn.active {
            color: #667eea;
            border-bottom-color: #667eea;
        }
        
        .view-tab-content {
            display: none;
        }
        
        .view-tab-content.active {
            display: block;
        }
        
        .info-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 1.5rem;
            margin-top: 1rem;
        }
        
        .info-item label {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            color: #718096;
            font-weight: 500;
            margin-bottom: 0.5rem;
        }
        
        .info-item p {
            margin: 0;
            color: #2d3748;
            font-size: 1rem;
        }
        
        .stats-grid.small {
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1rem;
        }
        
        .stats-grid.small .stat-card {
            padding: 1rem;
        }
        
        .stats-grid.small .stat-icon {
            width: 40px;
            height: 40px;
            font-size: 1rem;
        }
        
        .stats-grid.small h3 {
            font-size: 1.25rem;
        }
        
        .order-status-chart {
            margin-top: 2rem;
            max-height: 300px;
        }
        
        .activity-timeline {
            margin-top: 1rem;
            display: flex;
            flex-direction: column;
            gap: 1rem;
        }
        
        .activity-item {
            display: flex;
            gap: 1rem;
            padding: 1rem;
            background: #f7fafc;
            border-radius: 8px;
        }
        
        .activity-icon {
            width: 40px;
            height: 40px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            flex-shrink: 0;
        }
        
        .activity-content {
            flex: 1;
        }
        
        .activity-action {
            margin: 0 0 0.25rem 0;
            font-weight: 500;
        }
        
        .activity-date {
            color: #718096;
            font-size: 0.85rem;
        }
        
        .user-view-actions {
            display: flex;
            gap: 1rem;
            padding-top: 1.5rem;
            border-top: 1px solid #e2e8f0;
        }
        
        .loading {
            text-align: center;
            padding: 2rem;
            color: #718096;
        }
        
        .notification {
            position: fixed;
            top: 20px;
            right: 20px;
            padding: 1rem 1.5rem;
            border-radius: 8px;
            color: white;
            display: flex;
            align-items: center;
            gap: 0.75rem;
            z-index: 10000;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
            animation: slideIn 0.3s ease-out;
        }
        
        .notification-success {
            background: #38a169;
        }
        
        .notification-error {
            background: #e53e3e;
        }
        
        .notification-info {
            background: #3182ce;
        }
        
        @keyframes slideIn {
            from {
                transform: translateX(100%);
                opacity: 0;
            }
            to {
                transform: translateX(0);
                opacity: 1;
            }
        }
        
        @media (max-width: 768px) {
            .user-view-header {
                flex-direction: column;
                text-align: center;
            }
            
            .user-status {
                justify-content: center;
            }
            
            .user-view-actions {
                flex-direction: column;
            }
            
            .action-buttons {
                flex-wrap: wrap;
            }
            
            .info-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</body>
</html>
