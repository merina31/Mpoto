<?php
session_start();
require_once '../includes/config.php';
require_once '../includes/db_connect.php';
require_once '../includes/auth_functions.php';

$auth->requireAdmin();
$db = Database::getInstance();
$adminId = (int) $_SESSION['user_id'];

$createSql = "CREATE TABLE IF NOT EXISTS notifications (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    sender_id INT,
    message TEXT,
    link VARCHAR(255),
    unread BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
$db->prepare($createSql)->execute();

if (isset($_GET['ajax']) && $_GET['ajax'] === '1') {
    header('Content-Type: application/json');
    $action = $_GET['action'] ?? $_POST['action'] ?? 'list';

    if ($action === 'list') {
        $filter = $_GET['filter'] ?? 'all';
        $where = "WHERE n.user_id = ?";
        if ($filter === 'read') {
            $where .= " AND n.unread = 0";
        } elseif ($filter === 'unread') {
            $where .= " AND n.unread = 1";
        }

        $stmt = $db->prepare("
            SELECT n.*, u.full_name AS sender_name, u.username AS sender_username
            FROM notifications n
            LEFT JOIN users u ON u.id = n.sender_id
            {$where}
            ORDER BY n.created_at DESC
        ");
        $stmt->bind_param('i', $adminId);
        $stmt->execute();
        $rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

        $countStmt = $db->prepare("
            SELECT
                COUNT(*) AS total_count,
                SUM(CASE WHEN unread = 1 THEN 1 ELSE 0 END) AS unread_count
            FROM notifications
            WHERE user_id = ?
        ");
        $countStmt->bind_param('i', $adminId);
        $countStmt->execute();
        $counts = $countStmt->get_result()->fetch_assoc() ?: [];

        $totalCount = (int) ($counts['total_count'] ?? 0);
        $unreadCount = (int) ($counts['unread_count'] ?? 0);
        $readCount = $totalCount - $unreadCount;

        echo json_encode([
            'success' => true,
            'notifications' => $rows,
            'counts' => [
                'total' => $totalCount,
                'unread' => $unreadCount,
                'read' => $readCount
            ]
        ]);
        exit();
    }

    if ($action === 'read') {
        $id = (int) ($_POST['id'] ?? 0);
        if ($id <= 0) {
            echo json_encode(['success' => false, 'message' => 'Invalid notification ID']);
            exit();
        }

        $update = $db->prepare("UPDATE notifications SET unread = 0 WHERE id = ? AND user_id = ?");
        $update->bind_param('ii', $id, $adminId);
        $update->execute();

        $stmt = $db->prepare("
            SELECT n.*, u.full_name AS sender_name, u.username AS sender_username, u.email AS sender_email
            FROM notifications n
            LEFT JOIN users u ON u.id = n.sender_id
            WHERE n.id = ? AND n.user_id = ?
            LIMIT 1
        ");
        $stmt->bind_param('ii', $id, $adminId);
        $stmt->execute();
        $row = $stmt->get_result()->fetch_assoc();

        if (!$row) {
            echo json_encode(['success' => false, 'message' => 'Notification not found']);
            exit();
        }

        echo json_encode(['success' => true, 'notification' => $row]);
        exit();
    }

    if ($action === 'delete') {
        $id = (int) ($_POST['id'] ?? 0);
        if ($id <= 0) {
            echo json_encode(['success' => false, 'message' => 'Invalid notification ID']);
            exit();
        }
        $stmt = $db->prepare("DELETE FROM notifications WHERE id = ? AND user_id = ?");
        $stmt->bind_param('ii', $id, $adminId);
        $stmt->execute();
        echo json_encode(['success' => true]);
        exit();
    }

    echo json_encode(['success' => false, 'message' => 'Unsupported action']);
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Notifications - Admin</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/admin_style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <?php include 'includes/admin_navbar.php'; ?>
    <div class="admin-container">
        <main class="admin-main">
            <header class="admin-header">
                <h1><i class="fas fa-bell"></i> Notifications</h1>
                <p>All user activity notifications for your admin account.</p>
            </header>

            <div class="admin-card">
                <div class="card-header">
                    <h3 id="notificationSummary">Loading notifications...</h3>
                    <button type="button" class="btn btn-secondary" onclick="loadNotifications()">
                        <i class="fas fa-sync-alt"></i> Refresh
                    </button>
                </div>
                <div class="card-body">
                    <div class="notification-filters">
                        <button type="button" class="filter-btn active" data-filter="all" onclick="setNotificationFilter('all', this)">
                            All
                        </button>
                        <button type="button" class="filter-btn" data-filter="unread" onclick="setNotificationFilter('unread', this)">
                            Unread
                        </button>
                        <button type="button" class="filter-btn" data-filter="read" onclick="setNotificationFilter('read', this)">
                            Read
                        </button>
                    </div>
                    <div id="notificationList" class="notification-list-page"></div>
                </div>
            </div>
        </main>
    </div>

    <div class="modal" id="notificationModal">
        <div class="modal-content large-modal">
            <div class="modal-header">
                <h2><i class="fas fa-info-circle"></i> Notification Details</h2>
                <button type="button" onclick="closeNotificationModal()">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <div class="modal-body" id="notificationModalBody"></div>
        </div>
    </div>

    <?php include 'includes/admin_footer.php'; ?>

    <script>
        let currentNotificationFilter = 'all';

        function setNotificationFilter(filter, buttonEl) {
            currentNotificationFilter = filter;
            document.querySelectorAll('.filter-btn').forEach(btn => btn.classList.remove('active'));
            if (buttonEl) {
                buttonEl.classList.add('active');
            } else {
                const target = document.querySelector(`.filter-btn[data-filter="${filter}"]`);
                if (target) target.classList.add('active');
            }
            loadNotifications();
        }

        async function loadNotifications() {
            const listEl = document.getElementById('notificationList');
            const summaryEl = document.getElementById('notificationSummary');
            listEl.innerHTML = '<p>Loading...</p>';

            try {
                const response = await fetch(`notifications.php?ajax=1&action=list&filter=${encodeURIComponent(currentNotificationFilter)}`);
                const data = await response.json();
                if (!data.success) {
                    listEl.innerHTML = '<p>Failed to load notifications.</p>';
                    summaryEl.textContent = 'Notifications';
                    return;
                }

                const notifications = data.notifications || [];
                const counts = data.counts || {};
                const total = Number(counts.total || 0);
                const unread = Number(counts.unread || 0);
                const read = Number(counts.read || 0);
                const filterLabel = currentNotificationFilter.charAt(0).toUpperCase() + currentNotificationFilter.slice(1);
                summaryEl.textContent = `Showing: ${filterLabel} | Total: ${total} | Unread: ${unread} | Read: ${read}`;

                if (notifications.length === 0) {
                    listEl.innerHTML = '<div class="empty-state"><i class="fas fa-bell-slash"></i><p>No notifications available.</p></div>';
                    return;
                }

                listEl.innerHTML = notifications.map(n => `
                    <div class="notification-row ${Number(n.unread) === 1 ? 'unread' : ''}">
                        <div class="notification-main">
                            <h4>${escapeHtml(n.message || 'Notification')}</h4>
                            <div class="notification-meta">
                                <span><i class="fas fa-user"></i> ${escapeHtml(n.sender_name || n.sender_username || 'System')}</span>
                                <span><i class="fas fa-clock"></i> ${new Date(n.created_at).toLocaleString()}</span>
                                <span class="badge ${Number(n.unread) === 1 ? 'badge-unread' : 'badge-read'}">
                                    ${Number(n.unread) === 1 ? 'Unread' : 'Read'}
                                </span>
                            </div>
                        </div>
                        <div class="notification-actions">
                            <button type="button" class="btn btn-primary btn-sm" onclick="readNotification(${Number(n.id)})">
                                <i class="fas fa-book-open"></i> Read
                            </button>
                            <button type="button" class="btn btn-danger btn-sm" onclick="deleteNotification(${Number(n.id)})">
                                <i class="fas fa-trash"></i> Delete
                            </button>
                        </div>
                    </div>
                `).join('');
            } catch (error) {
                console.error(error);
                listEl.innerHTML = '<p>An error occurred while loading notifications.</p>';
                summaryEl.textContent = 'Notifications';
            }
        }

        async function readNotification(id) {
            try {
                const formData = new FormData();
                formData.append('action', 'read');
                formData.append('id', String(id));

                const response = await fetch('notifications.php?ajax=1', {
                    method: 'POST',
                    body: formData
                });
                const data = await response.json();
                if (!data.success) {
                    alert(data.message || 'Failed to load notification details.');
                    return;
                }

                const n = data.notification;
                const modalBody = document.getElementById('notificationModalBody');
                const readStatus = Number(n.unread) === 1 ? 'Unread' : 'Read';
                modalBody.innerHTML = `
                    <div class="notification-detail-card">
                        <div class="detail-row"><span>Message</span><strong>${escapeHtml(n.message || 'N/A')}</strong></div>
                        <div class="detail-row"><span>Sender</span><strong>${escapeHtml(n.sender_name || n.sender_username || 'System')}</strong></div>
                        <div class="detail-row"><span>Sender Email</span><strong>${escapeHtml(n.sender_email || 'N/A')}</strong></div>
                        <div class="detail-row"><span>Date/Time</span><strong>${new Date(n.created_at).toLocaleString()}</strong></div>
                        <div class="detail-row"><span>Status</span><strong>${readStatus}</strong></div>
                        <div class="detail-row"><span>Link</span><strong>${n.link ? `<a href="${escapeHtml(n.link)}">${escapeHtml(n.link)}</a>` : 'N/A'}</strong></div>
                        <div class="detail-actions">
                            ${n.link ? `<a href="${escapeHtml(n.link)}" class="btn btn-secondary"><i class="fas fa-external-link-alt"></i> Open Link</a>` : ''}
                            <button type="button" class="btn btn-danger" onclick="deleteNotification(${Number(n.id)}, true)">
                                <i class="fas fa-trash"></i> Delete Notification
                            </button>
                        </div>
                    </div>
                `;

                document.getElementById('notificationModal').style.display = 'block';
                document.body.style.overflow = 'hidden';
                loadNotifications();
            } catch (error) {
                console.error(error);
                alert('An error occurred while opening notification details.');
            }
        }

        async function deleteNotification(id, fromModal = false) {
            if (!confirm('Delete this notification?')) return;

            try {
                const formData = new FormData();
                formData.append('action', 'delete');
                formData.append('id', String(id));

                const response = await fetch('notifications.php?ajax=1', {
                    method: 'POST',
                    body: formData
                });
                const data = await response.json();
                if (!data.success) {
                    alert(data.message || 'Failed to delete notification.');
                    return;
                }

                if (fromModal) {
                    closeNotificationModal();
                }
                loadNotifications();
            } catch (error) {
                console.error(error);
                alert('An error occurred while deleting notification.');
            }
        }

        function closeNotificationModal() {
            const modal = document.getElementById('notificationModal');
            modal.style.display = 'none';
            document.body.style.overflow = 'auto';
        }

        function escapeHtml(value) {
            return String(value ?? '')
                .replace(/&/g, '&amp;')
                .replace(/</g, '&lt;')
                .replace(/>/g, '&gt;')
                .replace(/"/g, '&quot;')
                .replace(/'/g, '&#039;');
        }

        window.addEventListener('click', function(event) {
            const modal = document.getElementById('notificationModal');
            if (event.target === modal) {
                closeNotificationModal();
            }
        });

        document.addEventListener('DOMContentLoaded', loadNotifications);
    </script>

    <style>
        .notification-filters {
            display: flex;
            gap: 0.6rem;
            margin-bottom: 1rem;
            flex-wrap: wrap;
        }

        .filter-btn {
            border: 1px solid #d1d5db;
            background: #ffffff;
            color: #1f2937;
            border-radius: 999px;
            padding: 0.35rem 0.85rem;
            font-size: 0.85rem;
            cursor: pointer;
            transition: all 0.2s ease;
        }

        .filter-btn:hover {
            border-color: #94a3b8;
            background: #f8fafc;
        }

        .filter-btn.active {
            background: #e0ecff;
            border-color: #5b8def;
            color: #1d4ed8;
            font-weight: 600;
        }

        .notification-list-page {
            display: flex;
            flex-direction: column;
            gap: 1rem;
        }

        .notification-row {
            display: flex;
            justify-content: space-between;
            gap: 1rem;
            align-items: flex-start;
            border: 1px solid #e2e8f0;
            border-radius: 10px;
            padding: 1rem;
            background: #fff;
        }

        .notification-row.unread {
            border-left: 5px solid #f59e0b;
            background: #fffdf4;
        }

        .notification-main {
            flex: 1;
            min-width: 0;
        }

        .notification-main h4 {
            margin: 0 0 0.5rem 0;
            font-size: 1rem;
        }

        .notification-meta {
            display: flex;
            flex-wrap: wrap;
            gap: 0.75rem;
            color: #64748b;
            font-size: 0.9rem;
        }

        .badge {
            border-radius: 999px;
            padding: 0.1rem 0.6rem;
            font-size: 0.75rem;
            font-weight: 600;
        }

        .badge-unread {
            background: #fef3c7;
            color: #92400e;
        }

        .badge-read {
            background: #dbeafe;
            color: #1e40af;
        }

        .notification-actions {
            display: flex;
            gap: 0.5rem;
            flex-wrap: wrap;
        }

        .btn-sm {
            padding: 0.4rem 0.75rem;
            font-size: 0.82rem;
        }

        .empty-state {
            text-align: center;
            color: #64748b;
            padding: 2rem 1rem;
            border: 1px dashed #cbd5e1;
            border-radius: 10px;
        }

        .empty-state i {
            font-size: 2rem;
            margin-bottom: 0.5rem;
        }

        .notification-detail-card {
            display: flex;
            flex-direction: column;
            gap: 0.75rem;
        }

        .detail-row {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            gap: 1rem;
            border-bottom: 1px solid #e2e8f0;
            padding-bottom: 0.6rem;
        }

        .detail-row span {
            color: #64748b;
            min-width: 140px;
        }

        .detail-row strong {
            text-align: right;
            word-break: break-word;
        }

        .detail-actions {
            display: flex;
            gap: 0.75rem;
            justify-content: flex-end;
            margin-top: 0.5rem;
            flex-wrap: wrap;
        }

        @media (max-width: 768px) {
            .notification-row {
                flex-direction: column;
            }

            .notification-actions {
                width: 100%;
            }

            .notification-actions .btn {
                flex: 1;
            }

            .detail-row {
                flex-direction: column;
                gap: 0.4rem;
            }

            .detail-row strong {
                text-align: left;
            }
        }
    </style>
</body>
</html>
