/**
 * CART SYSTEM IMPLEMENTATION GUIDE
 * 
 * This guide explains how to use the new cart system across your application
 */

// ============================================================
// 1. BASIC SETUP - Include on all pages that use cart
// ============================================================

// Add this line to your HTML <head> or before </body>:
// <script src="assets/js/cart.js"></script>

// For pages with PHP logic, add this to check if user is logged in:
// <script>
//     const isUserLoggedIn = <?php echo isset($_SESSION['user_id']) ? 'true' : 'false'; ?>;
// </script>


// ============================================================
// 2. ADD TO CART BUTTONS - Three ways to implement
// ============================================================

// METHOD 1: HTML Button with data attributes (RECOMMENDED)
// <button type="button" class="btn btn-primary" data-action="add-to-cart" data-meal-id="123" data-quantity="1">
//     <i class="fas fa-shopping-cart"></i> Add to Cart
// </button>

// METHOD 2: Call JavaScript directly (for custom handlers)
// <button type="button" onclick="addToCart(123, 1)">Add to Cart</button>

// METHOD 3: From dynamic content (JavaScript template literals)
// <button class="btn-add-cart" data-action="add-to-cart" data-meal-id="${meal.id}" data-quantity="1">
//     <i class="fas fa-shopping-cart"></i>
// </button>


// ============================================================
// 3. AVAILABLE FUNCTIONS
// ============================================================

/**
 * Add item to cart
 * @example addToCart(123, 1);
 */
function addToCart(mealId, quantity = 1, button = null) {
    // Implemented in cart.js
}

/**
 * Remove item from cart
 * @example removeFromCart(123, () => { console.log('Item removed'); });
 */
function removeFromCart(mealId, callback = null) {
    // Implemented in cart.js
}

/**
 * Update item quantity
 * @example updateCartQuantity(123, 5, () => { location.reload(); });
 */
function updateCartQuantity(mealId, quantity, callback = null) {
    // Implemented in cart.js
}

/**
 * Update cart count display
 * @example updateCartCount();
 */
function updateCartCount() {
    // Implemented in cart.js
}

/**
 * Clear entire cart
 * @example clearCart(() => { location.reload(); });
 */
function clearCart(callback = null) {
    // Implemented in cart.js
}

/**
 * Show notification
 * @example showNotification('Item added!', 'success');
 * @param {string} message - The message
 * @param {string} type - 'success', 'error', 'warning', or 'info'
 */
function showNotification(message, type = 'info') {
    // Implemented in cart.js
}

/**
 * Initialize cart buttons on page
 * Call this after dynamically loading content with add-to-cart buttons
 * @example initializeCartButtons();
 */
function initializeCartButtons() {
    // Implemented in cart.js
}


// ============================================================
// 4. INTEGRATION EXAMPLES
// ============================================================

// EXAMPLE 1: Add to cart from product page
// <button data-action="add-to-cart" data-meal-id="123" data-quantity="1">
//     Add to Cart
// </button>

// EXAMPLE 2: Add to cart with quantity selector
// <select id="quantity-selector">
//     <option value="1">1</option>
//     <option value="2">2</option>
//     <option value="3">3</option>
// </select>
// <button onclick="addToCart(123, parseInt(document.getElementById('quantity-selector').value))">
//     Add to Cart
// </button>

// EXAMPLE 3: Update quantity in cart page
// <input type="number" min="1" max="10" value="2" 
//        onchange="handleQuantityChange(123, this)">

// EXAMPLE 4: Remove item button
// <button onclick="removeFromCart(123, () => location.reload())">
//     Remove
// </button>

// EXAMPLE 5: Clear cart button
// <button onclick="clearCart()">
//     Clear Cart
// </button>


// ============================================================
// 5. CART ITEM STRUCTURE (Database)
// ============================================================

/*
The cart system stores items in the database with the following structure:

TABLE: cart
- id (INT, PRIMARY KEY)
- user_id (INT, FOREIGN KEY)
- meal_id (INT, FOREIGN KEY)
- quantity (INT)
- created_at (TIMESTAMP)
- updated_at (TIMESTAMP)

The system automatically:
- Checks if the meal is available before adding
- Updates quantity if item already exists in cart
- Prevents duplicate entries
- Validates user ownership
*/


// ============================================================
// 6. API ENDPOINTS
// ============================================================

/*
All requests go to: api/cart.php
Content-Type: application/json

GET /api/cart.php (requires login)
  Returns: Cart display page

POST /api/cart.php (AJAX)
  action: 'add'
    body: { action: 'add', meal_id: 123, quantity: 1 }
    returns: { success: true, message: '...', cart_count: 5, quantity: 1 }

  action: 'get_count'
    body: { action: 'get_count' }
    returns: { success: true, cart_count: 5 }

  action: 'update'
    body: { action: 'update', meal_id: 123, quantity: 5 }
    returns: { success: true, message: '...' }

  action: 'remove'
    body: { action: 'remove', meal_id: 123 }
    returns: { success: true, message: '...' }

  action: 'clear'
    body: { action: 'clear' }
    returns: { success: true, message: '...' }
*/


// ============================================================
// 7. NOTIFICATIONS
// ============================================================

// The system shows notifications for all cart actions:
// - Item added successfully
// - Item removed successfully
// - Cart updated
// - Error messages
// - Login required warnings

// Notification types and styling:
// - success: Green background, check icon
// - error: Red background, exclamation icon  
// - warning: Orange background, warning icon
// - info: Blue background, info icon

// Notifications auto-dismiss after 3 seconds
// Custom notification: showNotification('Your message', 'success');


// ============================================================
// 8. BUTTON STYLING
// ============================================================

/*
Add to cart buttons get automatic styling and state changes:

Default state:
  - Icon + Text
  - Primary color
  - Hover effect

Added state (temporary):
  - Green background
  - Check icon
  - Lasts 2 seconds

Loading state:
  - Spinner icon
  - Disabled
  - "Adding..." text

Classes available:
  .btn-add-cart - Base styling
  .added - Applied temporarily when item added successfully
  [data-action="add-to-cart"] - Selector for all cart buttons
*/


// ============================================================
// 9. EXAMPLE: Complete Product Display
// ============================================================

/*
<div class="meal-card">
    <div class="meal-image">
        <img src="<?php echo $meal['image_url']; ?>" alt="<?php echo $meal['name']; ?>">
    </div>
    <div class="meal-info">
        <h3><?php echo $meal['name']; ?></h3>
        <p><?php echo $meal['description']; ?></p>
        <div class="meal-price">
            <span>$<?php echo $meal['price']; ?></span>
        </div>
        <button type="button" 
                class="btn btn-primary" 
                data-action="add-to-cart" 
                data-meal-id="<?php echo $meal['id']; ?>" 
                data-quantity="1">
            <i class="fas fa-shopping-cart"></i> Add to Cart
        </button>
    </div>
</div>

<script src="assets/js/cart.js"></script>
*/


// ============================================================
// 10. SECURITY NOTES
// ============================================================

/*
The cart system includes:
- User authentication checks (requireLogin())
- SQL prepared statements (prevents SQL injection)
- User ownership verification (each user has separate cart)
- Meal availability verification (can't add unavailable meals)
- CORS headers for API security

All cart operations are:
- Database-backed (server-side storage)
- User-specific (isolated per user)
- Real-time synchronized
- Validated on server
*/
